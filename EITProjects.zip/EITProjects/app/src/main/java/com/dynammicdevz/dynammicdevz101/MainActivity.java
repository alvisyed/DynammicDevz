package com.dynammicdevz.dynammicdevz101;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.PersistableBundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import static android.view.KeyCharacterMap.load;

public class MainActivity extends AppCompatActivity {
    String TAG="TAG_X";
    private Button followButton;
    private TextView usernameTv;
    private TextView text2View;
    private ImageView imageView;
    private int count=0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d(TAG, "onCreate: ");
        followButton=findViewById(R.id.follow_button);
        usernameTv=findViewById(R.id.username_textview);
        text2View=findViewById(R.id.text2);
        followButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                count = count + 5;
                setCountText();


                if (count == 5) {
                    //imageView.setImageResource(R.drawable.duck);


                    Glide.with(MainActivity.this)
                            .applyDefaultRequestOptions(RequestOptions.circleCropTransform())
                            .load(R.drawable.toddler)
                            .into(imageView);

                } else if (count == 10) {
                    //imageView.setImageResource(R.drawable.ic_launcher_background);
                    Glide.with(MainActivity.this)
                            .applyDefaultRequestOptions(RequestOptions.circleCropTransform())
                            .load(R.drawable.tenyear)
                            .into(imageView);
                } else if (count == 15) {
                    //imageView.setImageResource(R.drawable.ic_launcher_background);
                    Glide.with(MainActivity.this)
                            .applyDefaultRequestOptions(RequestOptions.circleCropTransform())
                            .load(R.drawable.fifteen)
                            .into(imageView);
                } else if (count == 20) {
                    //imageView.setImageResource(R.drawable.ic_launcher_background);
                    Glide.with(MainActivity.this)
                            .applyDefaultRequestOptions(RequestOptions.circleCropTransform())
                            .load(R.drawable.adult)
                            .into(imageView);
                }



            }







        });
        imageView=findViewById(R.id.profile_imageview);



    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        count=savedInstanceState.getInt("Count_Key");
        setCountText();
    }

    private void setCountText() {
        if(count<=20){
        usernameTv.setText("When I was "+count);
        }else { usernameTv.setText("Thank You");
        text2View.setText("This Application was developed by DynamicDevs.");

        }
    }


    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        Log.d(TAG, "onSaveInstanceState: ");
        outState.putInt("Count_Key", count);
    }

    protected void onStart() {

        super.onStart();
        Log.d(TAG, "onStart: ");
    }
    protected void onResume() {

        super.onResume();
        Log.d(TAG, "onResume: ");
    }
    protected void onPause() {

        super.onPause();
        Log.d(TAG, "onPause: ");
    }
    protected void onStop() {

        super.onStop();
        Log.d(TAG, "onStop: ");
    }
    protected void onDestroy() {

        super.onDestroy();
        Log.d(TAG, "onDestroy: ");
    }
    protected void onRestart() {

        super.onRestart();
        Log.d(TAG, "onRestart: ");
    }

}